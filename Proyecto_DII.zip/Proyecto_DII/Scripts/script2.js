
var guardar = document.getElementById("guardar");
guardar.onclick = guardar_localstorage;



function guardar_localstorage(){
	var pis=document.getElementById("pista").value;
	var hor=document.getElementById("hora").value;
	var fec=document.getElementById("fecha").value;
	var nam=document.getElementById("name").value;
	var apes=document.getElementById("apellidos").value;
	var ema=document.getElementById("email").value;
	let persona = {
		Pista: pis,
		Hora: hor,
		Fecha: fec,
		Nombre: nam,
		Apellidos: apes,
		Email: ema
};
localStorage.setItem("persona", JSON.stringify(persona));

}


var letras = ["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E","T"];
var inputdni = document.getElementById("dni");
inputdni.onkeyup = ponerLetra;

function calcDni(numero) {
  var calc = numero % 23;
  return letras[calc];
}

function ponerLetra(){
	document.getElementById("ldni").value = calcDni(inputdni.value);
}



var enviar_factura = document.getElementById("enviar");
enviar_factura.onclick = crearFacturaSi;



function crearFacturaSi() {
		var form_nombre = document.getElementById("name").value;
		var form_apellido = document.getElementById("apellidos").value;
		var form_dni = document.getElementById("dni").value;
		var form_email = document.getElementById("email").value;
		var form_pista = document.getElementById("pista").value;
		var form_fecha = document.getElementById("fecha").value;

				
		if (form_nombre=="" || form_apellido=="" || form_dni=="" || form_email==""  || form_pista=="0" || form_fecha==""){		
		alert("Rellene todos los datos.");	
		} else {	
	}
}
