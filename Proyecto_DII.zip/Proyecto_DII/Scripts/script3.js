var mostrar = document.getElementById("confirmar");
mostrar.onclick = obtener_localstorage;

function obtener_localstorage(){
	if(localStorage.getItem("persona")){
		persona2=localStorage.getItem("persona");
		var persona3="";
		personasplit=persona2.split(",");
		for (var i=0; i < personasplit.length; i++) {
			persona3=persona3+(personasplit[i] + "  /  ");
		 }


		var personaa=JSON.parse(localStorage.getItem('persona')); 
		console.log(personaa);

		var nombree="";
		var apellidoo="";
		var emaill="";
		var pistaa="";
		var fechaa="";
		var horaa="";
		nombree=personaa.Nombre;
		apellidoo=personaa.Apellidos;
		emaill=personaa.Email;
		pistaa=personaa.Pista;
		fechaa=personaa.Fecha;
		horaa=personaa.Hora;

		var escribir_factura = document.getElementById("factura");
		escribir_factura.innerHTML = `
		
		<div class="facturaa">
		<table id="table2">
		<h2 class="h2_datosf"><strong><u>Datos de la Persona</u></strong></h2>
			<tr>
				<td class="td_datos1">Nombre: </td>
				<td class="td_datos2">` + nombree + `</td>
			</tr>
			 <tr>
				<td class="td_datos1">Apellidos: </td>
				<td class="td_datos2">` + apellidoo + `</td>				
			</tr>
			<tr>
				<td class="td_datos1">Email: </td>
				<td class="td_datos2">` + emaill + `</td>
			</tr>
		</table>
		<table id="table3">
		<h2 class="h2_datosf2"><strong><u>Datos de la Reserva</u></strong></h2>
		<tr>
				<td class="td_datos1">Pista Reservada: </td>
				<td class="td_datos2 precios">` + pistaa + `</td>
			</tr>	
			<tr>
				<td class="td_datos1">Fecha de Reserva: </td>
				<td class="td_datos2 precios">` + fechaa + `</td>
			</tr>	
			<tr>
				<td class="td_datos1">Hora de Reserva: </td>
				<td class="td_datos2">` + horaa + `</td>
			</tr>
			<tr>
				<td class="td_datos1">Importe: </td>
				<td class="td_datos2">12,10€</td>
			</tr>
			<tr>
			<td class="td_datos1">Modalidad: </td>
			<td class="td_datos2">Fútbol</td>
		</tr>
		</table>
		</div>
	<p class="parrafoFinal">Si los datos son correctos, lo último que tiene que hacer es <strong>descargar</strong> el PDF que tendrá que presentar en el Centro Deportivo para realizar el pago en efectivo previo al inicio de su reserva.</p>
	<div id="text-center2">
		<button type="submit" id="botonpdf" >Descargar PDF</button>
	</div>`;
	}else{
		console.log("No hay entradas en el local de storage.")
	}

	document.getElementById("botonpdf").onclick = crearPDF;

			
	function crearPDF(){
		var doc = new jsPDF();

		doc.addFileToVFS("fuentes/verdana.ttf", verdana);
		doc.addFont("fuentes/verdana.ttf", "verdana", "normal");  
		doc.setFont("verdana");
		doc.setFontType("normal"); 


		doc.autoTable({styles:{ font: "verdana"}, html:'#table2'});

		doc.autoTable({styles:{ font: "verdana"},html:'#table3'});

		doc.save("RESERVA CD BAMI.pdf");
	}	
}
